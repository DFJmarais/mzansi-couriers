import UIKit
import Capacitor

class BridgeViewController: CAPBridgeViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Request App Tracking Transparency permission
        AppTrackingTransparencyHelper.shared.requestTrackingPermission()
        
        do {
            try setupWebView()
        } catch {
            print("ERROR: Failed to setup web view: \(error)")
            showErrorAlert(message: "Failed to load app. Please restart.")
        }
    }
    
    private func setupWebView() throws {
        // Ensure webView is initialized
        guard let webView = self.webView else {
            throw NSError(domain: "BridgeViewController", code: 1, userInfo: [NSLocalizedDescriptionKey: "WebView not initialized"])
        }
        
        // Configure the web view settings
        let config = webView.configuration
        
        // Enable file access from file URLs
        config.preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")
        config.setValue(true, forKey: "allowUniversalAccessFromFileURLs")
        
        // Set the server base path
        self.setServerBasePath("public")
        
        // Try to load index.html from the public folder
        if let indexPath = Bundle.main.path(forResource: "index", ofType: "html", inDirectory: "public") {
            let indexURL = URL(fileURLWithPath: indexPath)
            let request = URLRequest(url: indexURL)
            webView.load(request)
        } else {
            print("WARNING: index.html not found in public folder, trying alternative paths")
            
            // Try alternative paths
            let alternativePaths = [
                Bundle.main.bundlePath + "/public/index.html",
                Bundle.main.bundlePath + "/index.html",
                Bundle.main.resourcePath! + "/public/index.html"
            ]
            
            var loaded = false
            for path in alternativePaths {
                if FileManager.default.fileExists(atPath: path) {
                    let url = URL(fileURLWithPath: path)
                    let request = URLRequest(url: url)
                    webView.load(request)
                    loaded = true
                    print("Successfully loaded from: \(path)")
                    break
                }
            }
            
            if !loaded {
                throw NSError(domain: "BridgeViewController", code: 2, userInfo: [NSLocalizedDescriptionKey: "index.html not found in any expected location"])
            }
        }
    }
    
    private func showErrorAlert(message: String) {
        let alert = UIAlertController(title: "App Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        self.present(alert, animated: true)
    }
}
