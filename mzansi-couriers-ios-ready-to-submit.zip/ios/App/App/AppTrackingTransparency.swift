import UIKit
import AppTrackingTransparency
import AdSupport

class AppTrackingTransparencyHelper {
    static let shared = AppTrackingTransparencyHelper()
    
    func requestTrackingPermission() {
        // Only request on iOS 14+
        if #available(iOS 14, *) {
            DispatchQueue.main.async {
                ATTrackingManager.requestTrackingAuthorization { status in
                    switch status {
                    case .authorized:
                        print("[ATT] User authorized tracking")
                        let idfa = ASIdentifierManager.shared().advertisingIdentifier.uuidString
                        print("[ATT] IDFA: \(idfa)")
                    case .denied:
                        print("[ATT] User denied tracking")
                    case .notDetermined:
                        print("[ATT] Tracking permission not determined")
                    case .restricted:
                        print("[ATT] Tracking restricted")
                    @unknown default:
                        print("[ATT] Unknown tracking status")
                    }
                }
            }
        }
    }
}
